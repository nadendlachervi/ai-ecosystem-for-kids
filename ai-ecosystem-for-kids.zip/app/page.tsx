"use client"

import StudyCompanion from "../src/components/companions/StudyCompanion"

export default function SyntheticV0PageForDeployment() {
  return <StudyCompanion />
}